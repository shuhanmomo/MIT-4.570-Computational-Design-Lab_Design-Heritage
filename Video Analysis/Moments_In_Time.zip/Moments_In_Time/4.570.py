import os
import csv
import sys
import subprocess
import math
import cv2 as cv


filename = "Test"
second_interval = 4

_filename = filename + '.mp4'
csv_filename = filename + '_prediction.csv'

timestamp = 0

header = ["timestamp", 'prediction_1', 'accuracy_1', 'prediction_2', 'accuracy_2', 'prediction_3', 'accuracy_3', 'prediction_4', 'accuracy_4', 'prediction_5', 'accuracy_5']
data = []

with open(csv_filename, 'w', encoding='UTF8', newline='') as f:
    writer = csv.writer(f)

    writer.writerow(header)

    f.close()

os.system("ffmpeg -i " + _filename +" -c copy -map 0 -segment_time 00:00:03 -f segment -reset_timestamps 1 process/output%03d.mp4")

#os.system("ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1" + filename)

#length = subprocess.Popen(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1" + filename], stdout=subprocess.PIPE)
#length = subprocess.Popen(['ffprobe', '-show_format', '-pretty', '-loglevel', 'quiet', filename], stdout=subprocess.PIPE)
#(out, err) = length.communicate()
#test = os.system("ffprobe -i DSC_5203.mp4 -show_format | grep duration")
result = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
        "format=duration", "-of",
        "default=noprint_wrappers=1:nokey=1", _filename],
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT)

d = math.floor(float(result.stdout))
segments = math.floor(d / second_interval)

for i in range(0, segments):
    subdata = []
    if i <= 9:
        name = "process/output00" + str(i) + ".mp4"
    elif i >= 10 and i <= 99:
        name = "process/output0" + str(i) + ".mp4"
    else:
        name = "process/output" + str(i) + ".mp4"

    # nameList = []
    # CropImage(name, nameList)
    # if len(nameList) != 0:
    #     for i in nameList:
    x = subprocess.Popen(["python", "test_video_test.py", "--video_file", name, "--arch", "resnet3d50"], stdout=subprocess.PIPE)
    print(x)
    (out, err) = x.communicate()
    subdata = out.decode('utf-8').split('\n')
    subdata.pop()
    subdata.insert(0,timestamp)
    timestamp += second_interval
    data.append(subdata)
    print(subdata)

    with open(csv_filename, 'a', encoding='UTF8', newline='') as f:
        writer = csv.writer(f)

        writer.writerow(subdata)

        f.close()
